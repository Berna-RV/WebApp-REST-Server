cd 2trabalho
gradle bootRun